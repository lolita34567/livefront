from django.apps import AppConfig


class JinjatestConfig(AppConfig):
    name = 'jinjaTest'
